package com.example.demo.services;

import com.example.demo.dto.TarjetaCreditoDTO;
import com.example.demo.entities.TarjetaCredito;
import java.util.List;
import java.util.Optional;

public interface TarjetaCreditoService {
    TarjetaCredito crear(TarjetaCreditoDTO dto);
    Optional<TarjetaCredito> buscarPorId(Long id);
    List<TarjetaCredito> listarTodas();
    TarjetaCredito actualizar(TarjetaCreditoDTO dto);
    void eliminar(Long id);
}